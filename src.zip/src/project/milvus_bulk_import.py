# src/project/milvus_bulk_import.py

import argparse
import logging
from pathlib import Path
from minio import Minio
from pymilvus import utility, connections

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- MinIO/S3 Connection Details ---
MINIO_ENDPOINT = "localhost:9000"
MINIO_ACCESS_KEY = "minioadmin"
MINIO_SECRET_KEY = "minioadmin"
BUCKET_NAME = "milvus-bulk-import"

# --- Milvus Connection Details ---
MILVUS_HOST = "localhost"
MILVUS_PORT = "19530"

def upload_to_minio(data_dir: Path, client: Minio) -> list[str]:
    """Uploads prepared data files to the MinIO bucket."""
    files_uploaded = []
    try:
        if not client.bucket_exists(BUCKET_NAME):
            client.make_bucket(BUCKET_NAME)
            logging.info(f"Created bucket '{BUCKET_NAME}'")
        
        for file_path in data_dir.glob("*.json"):
            object_name = file_path.name
            client.fput_object(
                bucket_name=BUCKET_NAME,
                object_name=object_name,
                file_path=str(file_path),
            )
            logging.info(f"Successfully uploaded {file_path.name}")
            files_uploaded.append(object_name)
    except Exception as e:
        logging.error(f"Failed to upload files to MinIO: {e}")
        raise
    return files_uploaded

def main(data_dir: str, collection_name: str):
    """Orchestrates uploading data and triggering the Milvus bulk import."""
    data_path = Path(data_dir)

    # 1. Connect to MinIO and upload files
    minio_client = Minio(MINIO_ENDPOINT, access_key=MINIO_ACCESS_KEY, secret_key=MINIO_SECRET_KEY, secure=False)
    uploaded_files = upload_to_minio(data_path, minio_client)
    if not uploaded_files:
        logging.warning("No prepared data files found to upload.")
        return

    # 2. Connect to Milvus
    connections.connect("default", host=MILVUS_HOST, port=MILVUS_PORT)
    logging.info(f"Connected to Milvus at {MILVUS_HOST}:{MILVUS_PORT}")

    # 3. Trigger the bulk import job
    logging.info("Starting Milvus bulk import job...")
    try:
        task_ids_response = utility.do_bulk_insert(
            collection_name=collection_name,
            files=uploaded_files
        )
        task_ids = task_ids_response if isinstance(task_ids_response, list) else [task_ids_response]
        logging.info(f"Bulk insert job started with Task ID(s): {task_ids}")

        for task_id in task_ids:
            state = utility.get_bulk_insert_state(task_id=task_id)
            logging.info(f"Initial state for Task {task_id}: {state.state_name}")

    except Exception as e:
        logging.error(f"An error occurred during bulk import: {e}", exc_info=True)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Upload prepared data and trigger Milvus bulk import.")
    parser.add_argument("--data-dir", type=str, required=True, help="Directory with prepared JSON files.")
    parser.add_argument("--collection-name", type=str, default="rag_collection", help="Name of the Milvus collection.")
    args = parser.parse_args()
    main(args.data_dir, args.collection_name)