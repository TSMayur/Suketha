# src/project/embedder.py

from typing import List
from project.pydantic_models import Chunk, EmbeddingModel
from langchain_huggingface import HuggingFaceEmbeddings

def embed_chunks(chunks: List[Chunk], model_name: str = EmbeddingModel.ALL_MPNET_BASE_V2.value) -> List[Chunk]:
    """
    Generates vector embeddings for a list of Chunk objects.
    """
    if not chunks:
        return []

    encoder = HuggingFaceEmbeddings(
        model_name=model_name,
        model_kwargs={'device': 'cpu'}
    )
    
    # Corrected: used chunk.chunk_text instead of chunk.content
    texts_to_embed = [chunk.chunk_text for chunk in chunks]
    
    embeddings = encoder.embed_documents(texts_to_embed)
    
    for i, chunk in enumerate(chunks):
        chunk.embedding = embeddings[i]
        
    return chunks