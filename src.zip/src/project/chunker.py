# src/project/chunker.py

import logging
import json
from typing import List
import tiktoken

from .pydantic_models import Chunk, ChunkingMethod, ProcessingConfig, Document, DocumentType
from langchain.text_splitter import (
    RecursiveCharacterTextSplitter,
    RecursiveJsonSplitter,
)

logger = logging.getLogger(__name__)

try:
    TOKENIZER = tiktoken.get_encoding("cl100k_base")
except:
    TOKENIZER = None

class ChunkingService:
    @staticmethod
    def chunk_document(document: Document, config: ProcessingConfig) -> List[Chunk]:
        print(f"Chunking document '{document.id}' with method: {config.chunking_method.value}")
        if document.document_type == DocumentType.JSON:
            return ChunkingService._json_chunking(document, config)
        else:
            return ChunkingService._recursive_chunking(document, config)

    @staticmethod
    def _recursive_chunking(document: Document, config: ProcessingConfig) -> List[Chunk]:
        splitter = RecursiveCharacterTextSplitter(
            chunk_size=config.chunk_size,
            chunk_overlap=config.chunk_overlap,
            separators=["\n\n", "\n", " ", ""]
        )
        texts = splitter.split_text(document.content)
        return ChunkingService._create_chunks_from_texts(texts, document, config)

    @staticmethod
    def _json_chunking(document: Document, config: ProcessingConfig) -> List[Chunk]:
        splitter = RecursiveJsonSplitter(max_chunk_size=config.chunk_size)
        try:
            if not document.content.strip():
                return []
            json_data = json.loads(document.content)
            if not json_data: return []
            texts = [json.dumps(chunk) for chunk in splitter.split_json(json_data=json_data)]
            return ChunkingService._create_chunks_from_texts(texts, document, config)
        except (json.JSONDecodeError, IndexError) as e:
            logging.warning(f"Could not process JSON for {document.id}: {e}. Falling back to text chunking.")
            return ChunkingService._recursive_chunking(document, config)

    @staticmethod
    def _create_chunks_from_texts(texts: List[str], document: Document, config: ProcessingConfig) -> List[Chunk]:
        chunks = []
        for i, text in enumerate(texts):
            if len(text.strip()) >= 10:
                token_count = len(TOKENIZER.encode(text)) if TOKENIZER else None
                
                chunk = Chunk(
                    id=f"{document.id}_chunk_{i}", # Corrected: used 'id' instead of 'chunk_id'
                    doc_id=document.id,
                    chunk_text=text.strip(),
                    chunk_index=i,
                    chunk_method=config.chunking_method,
                    chunk_size=len(text),
                    chunk_tokens=token_count,
                    chunk_overlap=config.chunk_overlap,
                    content_type=document.document_type.value
                )
                chunks.append(chunk)
        return chunks