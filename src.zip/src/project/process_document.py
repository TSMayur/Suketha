# src/project/process_document.py

import argparse
import asyncio
import json
import logging
import time
import queue
from multiprocessing import Process, Queue, cpu_count
from pathlib import Path

from project.pydantic_models import ProcessingConfig
from project.doc_reader import DocumentReader
from project.chunker import ChunkingService
from project.storage_manager import StorageManager

# --- Configuration ---
# Enhanced logging with timestamps and process info
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(processName)s - %(levelname)s - %(message)s'
)


# --- Worker Process for Embedding ---

def embedding_worker(
    task_queue: Queue,
    results_queue: Queue,
    model_name: str
):
    """
    A worker process that pulls chunks from a queue, embeds them,
    and puts the results back on another queue.
    """
    from project.embedder import embed_chunks
    logging.info("Embedding worker started and model loaded.")

    while True:
        try:
            chunk_batch = task_queue.get(timeout=1)
            if chunk_batch is None:
                results_queue.put(None) # Signal completion
                break

            start_time = time.time()
            embedded_batch = embed_chunks(chunk_batch, model_name=model_name)
            
            # Convert Pydantic objects to dictionaries for serialization
            results_queue.put([chunk.dict() for chunk in embedded_batch])
            
            duration = time.time() - start_time
            logging.info(f"Embedded a batch of {len(chunk_batch)} chunks in {duration:.2f} seconds.")
        except queue.Empty:
            continue
        except Exception as e:
            logging.error(f"Error embedding a batch: {e}", exc_info=True)

    logging.info("Embedding worker finished.")


# --- Asynchronous Saver ---

async def save_results_async(
    results_queue: Queue,
    output_path: Path,
    filename: str,
    num_workers: int
):
    """
    Asynchronously collects embedded chunks and appends them to a file
    as they become available.
    """
    output_file = output_path / filename
    if output_file.exists():
        logging.warning(f"Output file {output_file} already exists. It will be overwritten.")
        output_file.unlink()

    workers_finished = 0
    total_chunks_saved = 0
    
    with open(output_file, "a", encoding="utf-8") as f:
        while workers_finished < num_workers:
            try:
                result_batch = results_queue.get_nowait()
                if result_batch is None:
                    workers_finished += 1
                    logging.info(f"A worker has finished. Total finished: {workers_finished}/{num_workers}")
                    continue

                for chunk_dict in result_batch:
                    f.write(json.dumps(chunk_dict) + "\n")
                
                batch_size = len(result_batch)
                total_chunks_saved += batch_size
                logging.info(f"Appended a batch of {batch_size} chunks. Total saved: {total_chunks_saved}")

            except queue.Empty:
                await asyncio.sleep(0.2)

    logging.info(f"All workers finished. Saving complete. Final chunk count: {total_chunks_saved}")


# --- Main Orchestrator ---

async def main_async(input_dir: str, output_dir: str, num_processes: int, chunk_size: int, chunk_overlap: int):
    """
    The main function to orchestrate the entire pipeline.
    """
    start_time = time.time()
    input_path = Path(input_dir)
    output_path = Path(output_dir)
    output_path.mkdir(exist_ok=True)

    config = ProcessingConfig(chunk_size=chunk_size, chunk_overlap=chunk_overlap)

    logging.info("Starting file discovery...")
    files_to_process = DocumentReader.find_files(input_path)
    logging.info(f"Found {len(files_to_process)} files.")

    all_chunks_to_process = []
    chunking_start_time = time.time()
    for file_path in files_to_process:
        try:
            document = DocumentReader.read_file(file_path)
            if document:
                chunks = ChunkingService.chunk_document(document, config)
                all_chunks_to_process.extend(chunks)
        except Exception as e:
            logging.error(f"Failed to read or chunk {file_path.name}: {e}")

    chunking_duration = time.time() - chunking_start_time
    total_chunks = len(all_chunks_to_process)
    logging.info(f"Finished chunking all files in {chunking_duration:.2f} seconds. Total chunks: {total_chunks}")

    if not all_chunks_to_process:
        logging.warning("No chunks were generated. Exiting.")
        return

    task_queue = Queue()
    results_queue = Queue()

    batch_size = 100  # Chunks per batch for embedding
    for i in range(0, total_chunks, batch_size):
        task_queue.put(all_chunks_to_process[i:i + batch_size])

    for _ in range(num_processes):
        task_queue.put(None)

    embedding_model = "sentence-transformers/all-mpnet-base-v2"
    processes = []
    for _ in range(num_processes):
        p = Process(
            target=embedding_worker,
            args=(task_queue, results_queue, embedding_model),
            name=f"EmbeddingWorker-{_+1}"
        )
        processes.append(p)
        p.start()

    save_task = asyncio.create_task(
        save_results_async(results_queue, output_path, "prepared_data.ndjson", num_processes)
    )

    # Wait for the saver task to complete
    await save_task

    # Clean up worker processes
    for p in processes:
        p.join()

    total_duration = time.time() - start_time
    logging.info(f"Entire pipeline finished in {total_duration:.2f} seconds.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process and embed documents for bulk import.")
    parser.add_argument("--input-dir", type=str, required=True, help="Directory containing raw documents.")
    parser.add_argument("--output-dir", type=str, required=True, help="Directory to save the prepared NDJSON file.")
    parser.add_argument("--num-processes", type=int, default=max(1, cpu_count() - 1), help="Number of CPU cores to use for embedding.")
    parser.add_argument("--chunk-size", type=int, default=1000, help="The size of each text chunk.")
    parser.add_argument("--chunk-overlap", type=int, default=200, help="The overlap between consecutive chunks.")
    
    args = parser.parse_args()
    
    # Run the main async function
    asyncio.run(main_async(args.input_dir, args.output_dir, args.num_processes, args.chunk_size, args.chunk_overlap))